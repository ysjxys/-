//
//  ViewController.h
//  AdaptiveAutoLayout
//
//  Created by Puzhi Li on 15/11/19.
//  Copyright © 2015年 Puzhi Li. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

